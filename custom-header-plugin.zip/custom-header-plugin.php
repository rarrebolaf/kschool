<?php
/**
 * Plugin Name: Cabecera Personalizada KS
 * Description: Cabecera personalizada con menú de WordPress
 * Version: 1.0.1
 * Author: Rafael Arrebola
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Verificar si la clase ya existe para evitar conflictos
if (!class_exists('KS_Custom_Header_Plugin')) {

    class KS_Custom_Header_Plugin {
        
        public function __construct() {
            // Definir constantes
            define('KS_HEADER_VERSION', '1.0.1');
            define('KS_HEADER_PATH', plugin_dir_path(__FILE__));
            define('KS_HEADER_URL', plugin_dir_url(__FILE__));
            
            // Cargar archivos necesarios
            $this->includes();
            
            // Inicializar
            add_action('plugins_loaded', array($this, 'init'));
        }
        
        private function includes() {
            require_once KS_HEADER_PATH . 'includes/class-ks-header.php';
            require_once KS_HEADER_PATH . 'includes/class-ks-header-walker.php';
        }
        
        public function init() {
            $ks_header = new KS_Header();
            $ks_header->init();
        }
    }

    // Instanciar el plugin
    new KS_Custom_Header_Plugin();

    // Registro de activación
    register_activation_hook(__FILE__, 'ks_header_activate');
    function ks_header_activate() {
        if (!current_user_can('activate_plugins')) return;
        
        add_option('ks_header_menu_location', 'primary');
        add_option('ks_header_logo_left', KS_HEADER_URL . 'assets/img/main-logo.svg');
        add_option('ks_header_logo_right', KS_HEADER_URL . 'assets/img/unir-logo.svg');
    }

    // Registro de desactivación
    register_deactivation_hook(__FILE__, 'ks_header_deactivate');
    function ks_header_deactivate() {
        // Limpieza opcional
    }
}