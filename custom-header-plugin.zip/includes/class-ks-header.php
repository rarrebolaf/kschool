<?php
/**
 * Clase principal para la cabecera personalizada
 * 
 * @package KS_Custom_Header
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente
}

if (!class_exists('KS_Header')) {

    class KS_Header {
        
        /**
         * Inicializar el plugin
         */
        public function init() {
            $this->register_menus();
            $this->setup_admin();
            $this->setup_frontend();
        }
        
        /**
         * Registrar menús
         */
        private function register_menus() {
            register_nav_menus(array(
                'ks_header_menu' => __('Menú Cabecera KS', 'ks-custom-header')
            ));
        }
        
        /**
         * Configurar el área de administración
         */
        private function setup_admin() {
            add_action('admin_init', array($this, 'register_settings'));
            add_action('admin_menu', array($this, 'add_admin_page'));
        }
        
        /**
         * Configurar el frontend
         */
        private function setup_frontend() {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
            add_action('wp_body_open', array($this, 'display_header'), 1);
        }
        
        /**
         * Registrar configuraciones
         */
        public function register_settings() {
            // Sección principal
            add_settings_section(
                'ks_header_section',
                __('Configuración Cabecera KS', 'ks-custom-header'),
                array($this, 'section_callback'),
                'ks_header_options'
            );
            
            // Campos de configuración
            $this->add_settings_field(
                'ks_header_menu_location',
                __('Ubicación del Menú', 'ks-custom-header'),
                'menu_location_callback'
            );
            
            $this->add_settings_field(
                'ks_header_logo_left',
                __('Logo Izquierdo', 'ks-custom-header'),
                'logo_left_callback'
            );
            
            $this->add_settings_field(
                'ks_header_logo_right',
                __('Logo Derecho', 'ks-custom-header'),
                'logo_right_callback'
            );
            
            // Registrar opciones
            register_setting('ks_header_options', 'ks_header_menu_location');
            register_setting('ks_header_options', 'ks_header_logo_left');
            register_setting('ks_header_options', 'ks_header_logo_right');
        }
        
        /**
         * Añadir campo de configuración
         */
        private function add_settings_field($id, $title, $callback) {
            add_settings_field(
                $id,
                $title,
                array($this, $callback),
                'ks_header_options',
                'ks_header_section'
            );
        }
        
        /**
         * Callback para la sección
         */
        public function section_callback() {
            echo '<p>' . __('Configura los ajustes de la cabecera personalizada.', 'ks-custom-header') . '</p>';
        }
        
        /**
         * Callback para selección de menú
         */
        public function menu_location_callback() {
            $menu_location = get_option('ks_header_menu_location', 'primary');
            $menus = get_registered_nav_menus();
            
            echo '<select name="ks_header_menu_location" class="regular-text">';
            foreach ($menus as $location => $description) {
                printf(
                    '<option value="%s" %s>%s</option>',
                    esc_attr($location),
                    selected($menu_location, $location, false),
                    esc_html($description)
                );
            }
            echo '</select>';
        }
        
        /**
         * Callback para logo izquierdo
         */
        public function logo_left_callback() {
            $logo_left = get_option('ks_header_logo_left', KS_HEADER_URL . 'assets/img/main-logo.svg');
            printf(
                '<input type="text" name="ks_header_logo_left" value="%s" class="regular-text">',
                esc_url($logo_left)
            );
            echo '<p class="description">' . __('URL completa del logo izquierdo', 'ks-custom-header') . '</p>';
        }
        
        /**
         * Callback para logo derecho
         */
        public function logo_right_callback() {
            $logo_right = get_option('ks_header_logo_right', KS_HEADER_URL . 'assets/img/unir-logo.svg');
            printf(
                '<input type="text" name="ks_header_logo_right" value="%s" class="regular-text">',
                esc_url($logo_right)
            );
            echo '<p class="description">' . __('URL completa del logo derecho', 'ks-custom-header') . '</p>';
        }
        
        /**
         * Añadir página de administración
         */
        public function add_admin_page() {
            add_options_page(
                __('Cabecera KS', 'ks-custom-header'),
                __('Cabecera KS', 'ks-custom-header'),
                'manage_options',
                'ks_header_options',
                array($this, 'admin_page_content')
            );
        }
        
        /**
         * Contenido de la página de administración
         */
        public function admin_page_content() {
            if (!current_user_can('manage_options')) {
                return;
            }
            
            settings_errors('ks_header_messages');
            ?>
            <div class="wrap">
                <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
                <form action="options.php" method="post">
                    <?php
                    settings_fields('ks_header_options');
                    do_settings_sections('ks_header_options');
                    submit_button(__('Guardar Cambios', 'ks-custom-header'));
                    ?>
                </form>
            </div>
            <?php
        }
        
        /**
         * Cargar assets
         */
        public function enqueue_assets() {
            // CSS
            $this->enqueue_style(
                'ks-header-style',
                'css/style.css'
            );
            
            $this->enqueue_style(
                'ks-header-responsive',
                'css/responsive.css',
                array('ks-header-style')
            );
            
            // Google Fonts
            wp_enqueue_style(
                'ks-header-fonts',
                'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap',
                array(),
                null
            );
            
            // JavaScript
            $this->enqueue_script(
                'ks-header-main',
                'js/main.js',
                array('jquery')
            );
            
            $this->enqueue_script(
                'ks-header-responsive',
                'js/responsive.js',
                array('jquery', 'ks-header-main')
            );
        }
        
        /**
         * Helper para cargar CSS
         */
        private function enqueue_style($handle, $path, $deps = array()) {
            wp_enqueue_style(
                $handle,
                KS_HEADER_URL . 'assets/' . $path,
                $deps,
                filemtime(KS_HEADER_PATH . 'assets/' . $path)
            );
        }
        
        /**
         * Helper para cargar JS
         */
        private function enqueue_script($handle, $path, $deps = array()) {
            wp_enqueue_script(
                $handle,
                KS_HEADER_URL . 'assets/' . $path,
                $deps,
                filemtime(KS_HEADER_PATH . 'assets/' . $path),
                true
            );
        }
        
        /**
         * Mostrar la cabecera
         */
        public function display_header() {
            $menu_location = get_option('ks_header_menu_location', 'primary');
            $logo_left = get_option('ks_header_logo_left', KS_HEADER_URL . 'assets/img/main-logo.svg');
            $logo_right = get_option('ks_header_logo_right', KS_HEADER_URL . 'assets/img/unir-logo.svg');
            
            $menu_args = array(
                'theme_location' => $menu_location,
                'container' => false,
                'menu_class' => 'menu',
                'fallback_cb' => false,
                'walker' => new KS_Header_Menu_Walker(),
                'items_wrap' => '<ul class="%2$s">%3$s</ul>'
            );
            ?>
            <header class="header">
                <div class="header__container">
                    <div class="header__logo-container">
                        <img src="<?php echo esc_url($logo_left); ?>" alt="Logo" class="header__logo-left"/>

                        <button class="header__hamburger" aria-label="Menú" aria-expanded="false">
                            <span class="header__hamburger-line"></span>
                            <span class="header__hamburger-line"></span>
                            <span class="header__hamburger-line"></span>
                        </button>
                    </div>
                    
                    <div class="header__left">
                        <nav class="header__nav">
                            <?php wp_nav_menu($menu_args); ?>
                        </nav>
                    </div>

                    <div class="header__right">
                        <div class="header__right-links">
                            <a href="#" class="header__link">Empleo</a>
                            <a href="#" class="header__link">Campus</a>
                        </div>
                        <div class="header__separator"></div>
                        <img src="<?php echo esc_url($logo_right); ?>" alt="Logo UNIR" class="header__logo-right"/>
                    </div>
                </div>
            </header>
            <?php
        }
    }
}